﻿using System.Configuration;
using System.Data;
using System.Windows;

namespace WPF_task1_containers_n_layouts_
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
    }
}
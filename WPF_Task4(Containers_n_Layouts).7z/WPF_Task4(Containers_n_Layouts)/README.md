# WPF_Task4-Containers_n_Layouts-
WrapPanel, StakePanel, TexBox

Разработать WPF-приложение, используя различные контейнеры
компоновки.

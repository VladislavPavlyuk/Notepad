﻿using System.Configuration;
using System.Data;
using System.Windows;

namespace WPF_Task3_Containers_n_Layouts_
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
    }
}
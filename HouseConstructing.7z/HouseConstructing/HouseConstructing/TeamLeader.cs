﻿using System;
using System.Collections;
using static HouseConstruction.Construction;

namespace HouseConstruction
{
    class TeamLeader : IWorker
    {
        TeamLeader leader; 

        public TeamLeader(string name, string occupation, int salary)
        {
            FullName = name;
            Occupation = occupation;
            Salary = salary;
        }

        public void Act()
        {
            try
            {
                Console.Write("\n" + Occupation + " " + FullName + " : ");

                ProgressReport();

            }
            catch (Exception)
            {              
                throw;
            }
        }
        public void Print()
        {
            Console.WriteLine("\n{0} \t {1} \t {2}", FullName, Occupation, Salary);
        }
        public void ProgressReport()
        {
            Console.WriteLine("\n Прогресс - " + CurrentProgress + " % !");

            Console.WriteLine(" Нажмите любую клавишу ... ");
        }


        public string FullName
        {
            set => _fullName = value;

            get => _fullName;
        }

        public int Salary
        {
            set => _salary = value;

            get => _salary;
        }

        public string Occupation
        {
            set => _occupation = value;

            get => _occupation;
        }
    }
}

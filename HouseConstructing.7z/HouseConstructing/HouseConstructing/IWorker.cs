﻿using System;

namespace HouseConstruction
{
    internal interface IWorker
    {
        public string FullName { get; set; }

        public int Salary { get; set; }

    }
}

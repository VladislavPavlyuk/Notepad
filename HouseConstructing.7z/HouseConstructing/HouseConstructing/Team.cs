﻿using System;
using System.Collections;
using static HouseConstruction.Construction;

namespace HouseConstruction
{
    public class Team : IWorker
    {
        ArrayList team;

        Worker worker;

        public Team ()
        {
            team = new ArrayList ();
        }

        public void Act()
        {
            try
            {
                for (int i = 1; i < Names.Length; i++)
                {
                    worker = new Worker(Names[i], Occupations[0], _salaryBase * 2);
                    
                    team.Add(worker);

                    worker.Print();
                }

                //PrintTeam();
            }
            catch (Exception)
            {
                throw;
            }
        }
        public void PrintTeam()
        {
            try
            {
                Console.Write("\n БРИГАДА : ");

                foreach (Worker temp in team)
                {
                    temp.Print();
                }
            }
            catch (Exception)
            {
                throw;
            }
        }

        public string FullName
        {
            set => _fullName = value;

            get => _fullName;
        }

        public int Salary
        {
            set => _salary = value;

            get => _salary;
        }

        public string Occupation
        {
            set => _occupation = value;

            get => _occupation;
        }
    }
}

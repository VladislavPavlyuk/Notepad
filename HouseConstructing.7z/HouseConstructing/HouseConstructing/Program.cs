﻿/*Реализовать программу “Строительство дома”
- Классы
    o House (Дом), Basement(Фундамент), Walls(Стены), Door(Дверь), Window(Окно), Roof(Крыша);
    o Team(Бригада строителей), Worker(Строитель), TeamLeader(Бригадир).
- Интерфейсы
    o IWorker, IPart.
Все части дома должны реализовать интерфейс IPart (Часть дома). Для рабочих и бригадира предоставляется базовый интерфейс IWorker (Рабочий).
Бригада строителей(Team) строит дом(House). Дом состоит из фундамента (Basement), стен(Wall), окон(Window), дверей(Door), крыши(Part).
В соответствии с проектом дом состоит из одного фундамента, четырёх стен, одной двери, четырёх окон и одной крыши.
Бригада начинает работу, и строители последовательно “строят” дом, начиная с фундамента. Каждый строитель не знает заранее на чём завершился предыдущий этап строительства, поэтому он “проверяет”, что уже построено и продолжает работу.
Если в игру вступает бригадир (TeamLeader), то он не строит, а формирует отчёт о том, что уже построено и какая часть р аботы выполнена.
В конечном итоге на консоль выводится сообщение, что строительство дома завершено и отображается “рисунок дома”*/

using System;
using System.Collections;


namespace HouseConstruction
{
    class Construction
    {
        ArrayList project = new ArrayList();

        static public int _basementCost;
        static public int _wallCost;
        static public int _doorCost;
        static public int _windowCost;
        static public int _roofCost;

        static public string _fullName;
        static public int _salary;
        static public int _salaryBase;
        static public string _occupation;

        static public string _partTitle;
        static public int _cost;
        static public int _progress;
        static public int _currentProgress;

        //static public enum Parts { Фундамент, Стены, Дверь, Окно, Крыша, Дом}
        static public readonly string[] PartName = { "Фундамент", "Стены", "Дверь", "Окно", "Крыша", "Дом" };

        static public readonly int[] ProgressWeight = { 25, 25, 5, 5, 25 };

        static public readonly int[] PartCosts = {  _basementCost, 
                                                    _wallCost, 
                                                    _doorCost, 
                                                    _windowCost, 
                                                    _roofCost };

        //public enum Occupations { Строитель, Бригадир, Бригада }

        static public readonly string[] Occupations = { "Строитель", "Бригадир" };
        
        //public enum Names { Аскольд, Дир, Олег, Игорь, Ольга, Святослав, Ярополк,  Владимир, Святополк, Ярослав, Изяслав, Всеслав, Всеволод }

        static public string[] Names = { "Аскольд", "Дир     ", "Олег    ", "Игорь  ", "Ольга  ", "Святослав", "Ярополк", "Владимир", "Святополк", "Ярослав", "Изяслав", "Всеслав", "Всеволод" };

        public Construction() { }

        public Construction(int basementCost, int wallCost, int doorCost, int windowCost, int roofCost, int salaryBase)
        {
            _basementCost = basementCost;
            _wallCost = wallCost;
            _doorCost = doorCost;
            _windowCost = windowCost;
            _roofCost = roofCost;
            _salaryBase = salaryBase;
        }

        public void Costs()
        {
            PartCosts[0] = _basementCost;
            PartCosts[1] = _wallCost;
            PartCosts[2] = _doorCost;
            PartCosts[3] = _windowCost;
            PartCosts[4] = _roofCost;
        }
        public void PrintError()
        {
            Console.WriteLine("\n Этап не выполнен!");
        }

        public void RunProject()
        {
            var rand = new Random();

            var bytes = new byte[Names.Length];
            rand.NextBytes(bytes);

            Costs();

            Team team = DevelopTeam(new());
            project.Add(team);
            

            TeamLeader leader = new TeamLeader(Names[0], Occupations[1], _salaryBase * 3);
            leader.Print();
            project.Add(leader);
            leader.ProgressReport();
            Console.ReadKey();

            if ((project.Contains(team)) && (project.Contains(leader)))
            {
                Basement obj = new();
                obj.Act();
                project.Add(obj);
                leader.ProgressReport();
            }
            else PrintError();
            Console.ReadKey();

            bool available = false;
            foreach (object o in project)
            {
                if (o is Basement)
                {
                    available = true;
                }
            }

                if (available)
                { 
                    Walls obj = new();
                    obj.Act();
                    project.Add(obj);
                    leader.ProgressReport();
                }         
                else PrintError(); 
            
            Console.ReadKey();


            available = false;
            foreach (object o in project)
            {
                if (o is Walls)
                {
                    available = true;
                }
            }

            if (available)
            {
                Door obj = new();
                obj.Act();
                project.Add(obj);
                leader.ProgressReport();
            }
            else PrintError();

            Console.ReadKey();

            available = false;
            foreach (object o in project)
            {
                if (o is Door)
                {
                    available = true;
                }
            }

            if (available)
            {
                Window obj = new();
                obj.Act();
                project.Add(obj);
                leader.ProgressReport();
                Console.ReadKey();

                obj.Act();
                project.Add(obj);
                leader.ProgressReport();
                Console.ReadKey();

                obj.Act();
                project.Add(obj);
                leader.ProgressReport();
                Console.ReadKey();

                obj.Act();
                project.Add(obj);
                leader.ProgressReport();
            }
            else PrintError();

            Console.ReadKey();

            foreach (object o in project)
            {
                if (o is Window)
                {
                    available = true;
                }
            }

            if (available)
            {
                Roof obj = new();
                obj.Act();
                project.Add(obj);
                leader.ProgressReport();
            }
            else PrintError();

            Console.ReadKey();


            available = false;
            foreach (object o in project)
            {
                if (o is Roof)
                {
                    available = true;
                }
            }

            if (available)
            {
                House obj = new();
                obj.Act();
                project.Add(obj);
                leader.ProgressReport();
            }
            else PrintError();

            Console.ReadKey();
        }

        static public int CurrentProgress
        {
            set => _currentProgress = value;

            get => _currentProgress;
        }

        public Team DevelopTeam(Team t)
        {
            t.Act();

            return t;
        }
    }

    class MainClass
    {
        public static void PrintValues(IEnumerable myList)
        {
            foreach (Object obj in myList)
                Console.Write("   {0}", obj);
            Console.WriteLine();
        }
        static void Main()
        {
            Console.Clear();

            Console.WriteLine("\tСТРОЙКА :\n");          
            
            Construction house = new Construction(5000, 4000, 1000, 1000, 5000, 500);

            house.RunProject();

        }
    }
}

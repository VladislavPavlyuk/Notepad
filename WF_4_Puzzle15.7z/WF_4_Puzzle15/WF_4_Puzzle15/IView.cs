﻿
namespace WF_4_Puzzle15
{
    public interface IView
    {
    }
}

﻿using System.Windows.Forms;

namespace WF_4_Puzzle15
{
    public interface IPresenter<T> where T : IView
    {
        T View { get; set; }
    }
}

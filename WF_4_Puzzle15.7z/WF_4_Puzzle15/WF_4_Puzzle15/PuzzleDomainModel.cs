﻿

namespace WF_4_Puzzle15;

public class PuzzleDomainModel : IPuzzleDomainModel
{
    private readonly IPuzzle puzzle = new Puzzle();

    #region IPuzzleDomainModel implementation

    public IPuzzle Puzzle => puzzle;


    #endregion
}

﻿using System;
using System.Windows.Forms;

namespace WF_TicTacToe
{
    partial class Game
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            pictureBox1 = new PictureBox();
            r1 = new PictureBox();
            r2 = new PictureBox();
            r3 = new PictureBox();
            r4 = new PictureBox();
            r6 = new PictureBox();
            r7 = new PictureBox();
            r8 = new PictureBox();
            r9 = new PictureBox();
            r5 = new PictureBox();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            pictureBox2 = new PictureBox();
            pictureBox3 = new PictureBox();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)r1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)r2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)r3).BeginInit();
            ((System.ComponentModel.ISupportInitialize)r4).BeginInit();
            ((System.ComponentModel.ISupportInitialize)r6).BeginInit();
            ((System.ComponentModel.ISupportInitialize)r7).BeginInit();
            ((System.ComponentModel.ISupportInitialize)r8).BeginInit();
            ((System.ComponentModel.ISupportInitialize)r9).BeginInit();
            ((System.ComponentModel.ISupportInitialize)r5).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
            SuspendLayout();
            // 
            // pictureBox1
            // 
            pictureBox1.BackColor = Color.Transparent;
            pictureBox1.Image = Properties.Resources.grid;
            pictureBox1.Location = new Point(4, 2);
            pictureBox1.Margin = new Padding(4, 3, 4, 3);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(395, 415);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 0;
            pictureBox1.TabStop = false;
            pictureBox1.Click += pictureBox1_Click;
            // 
            // r1
            // 
            r1.BackColor = Color.Transparent;
            r1.Location = new Point(13, 12);
            r1.Margin = new Padding(4, 3, 4, 3);
            r1.Name = "r1";
            r1.Size = new Size(97, 101);
            r1.SizeMode = PictureBoxSizeMode.Zoom;
            r1.TabIndex = 1;
            r1.TabStop = false;
            r1.Click += r1_Click;
            // 
            // r2
            // 
            r2.BackColor = Color.Transparent;
            r2.Location = new Point(146, 12);
            r2.Margin = new Padding(4, 3, 4, 3);
            r2.Name = "r2";
            r2.Size = new Size(105, 101);
            r2.SizeMode = PictureBoxSizeMode.Zoom;
            r2.TabIndex = 2;
            r2.TabStop = false;
            r2.Click += r2_Click;
            // 
            // r3
            // 
            r3.BackColor = Color.Transparent;
            r3.Location = new Point(282, 12);
            r3.Margin = new Padding(4, 3, 4, 3);
            r3.Name = "r3";
            r3.Size = new Size(105, 109);
            r3.SizeMode = PictureBoxSizeMode.Zoom;
            r3.TabIndex = 3;
            r3.TabStop = false;
            r3.Click += r3_Click;
            // 
            // r4
            // 
            r4.BackColor = Color.Transparent;
            r4.Location = new Point(11, 163);
            r4.Margin = new Padding(4, 3, 4, 3);
            r4.Name = "r4";
            r4.Size = new Size(99, 97);
            r4.SizeMode = PictureBoxSizeMode.Zoom;
            r4.TabIndex = 4;
            r4.TabStop = false;
            r4.Click += r4_Click;
            // 
            // r6
            // 
            r6.BackColor = Color.Transparent;
            r6.Location = new Point(294, 163);
            r6.Margin = new Padding(4, 3, 4, 3);
            r6.Name = "r6";
            r6.Size = new Size(105, 97);
            r6.SizeMode = PictureBoxSizeMode.Zoom;
            r6.TabIndex = 5;
            r6.TabStop = false;
            r6.Click += r6_Click;
            // 
            // r7
            // 
            r7.BackColor = Color.Transparent;
            r7.Location = new Point(13, 313);
            r7.Margin = new Padding(4, 3, 4, 3);
            r7.Name = "r7";
            r7.Size = new Size(108, 104);
            r7.SizeMode = PictureBoxSizeMode.Zoom;
            r7.TabIndex = 6;
            r7.TabStop = false;
            r7.Click += r7_Click;
            // 
            // r8
            // 
            r8.BackColor = Color.Transparent;
            r8.Location = new Point(146, 313);
            r8.Margin = new Padding(4, 3, 4, 3);
            r8.Name = "r8";
            r8.Size = new Size(105, 104);
            r8.SizeMode = PictureBoxSizeMode.Zoom;
            r8.TabIndex = 7;
            r8.TabStop = false;
            r8.Click += r8_Click;
            // 
            // r9
            // 
            r9.BackColor = Color.Transparent;
            r9.Location = new Point(294, 313);
            r9.Margin = new Padding(4, 3, 4, 3);
            r9.Name = "r9";
            r9.Size = new Size(105, 104);
            r9.SizeMode = PictureBoxSizeMode.Zoom;
            r9.TabIndex = 8;
            r9.TabStop = false;
            r9.Click += r9_Click;
            // 
            // r5
            // 
            r5.BackColor = Color.Transparent;
            r5.Location = new Point(146, 163);
            r5.Margin = new Padding(4, 3, 4, 3);
            r5.Name = "r5";
            r5.Size = new Size(105, 97);
            r5.SizeMode = PictureBoxSizeMode.Zoom;
            r5.TabIndex = 9;
            r5.TabStop = false;
            r5.Click += r5_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.Transparent;
            label1.Font = new Font("Microsoft Sans Serif", 30F, FontStyle.Italic, GraphicsUnit.Point);
            label1.ForeColor = Color.Red;
            label1.Location = new Point(4, 430);
            label1.Margin = new Padding(4, 0, 4, 0);
            label1.Name = "label1";
            label1.Size = new Size(47, 46);
            label1.TabIndex = 10;
            label1.Text = "X";
            label1.Click += label1_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.BackColor = Color.Transparent;
            label2.Font = new Font("Tahoma", 15F, FontStyle.Bold, GraphicsUnit.Point);
            label2.ForeColor = Color.Snow;
            label2.Location = new Point(48, 447);
            label2.Margin = new Padding(4, 0, 4, 0);
            label2.Name = "label2";
            label2.Size = new Size(94, 24);
            label2.TabIndex = 11;
            label2.Text = " PLAYER";
            label2.Click += label2_Click;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.BackColor = Color.Transparent;
            label3.Font = new Font("Tahoma", 15F, FontStyle.Bold, GraphicsUnit.Point);
            label3.ForeColor = Color.Snow;
            label3.Location = new Point(197, 447);
            label3.Margin = new Padding(4, 0, 4, 0);
            label3.Name = "label3";
            label3.Size = new Size(94, 24);
            label3.TabIndex = 13;
            label3.Text = " PLAYER";
            label3.Click += label3_Click;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.BackColor = Color.Transparent;
            label4.Font = new Font("Microsoft Sans Serif", 30F, FontStyle.Italic, GraphicsUnit.Point);
            label4.ForeColor = Color.Red;
            label4.Location = new Point(150, 430);
            label4.Margin = new Padding(4, 0, 4, 0);
            label4.Name = "label4";
            label4.Size = new Size(51, 46);
            label4.TabIndex = 12;
            label4.Text = "O";
            label4.Click += label4_Click;
            // 
            // pictureBox2
            // 
            pictureBox2.BackColor = Color.Transparent;
            pictureBox2.Image = Properties.Resources.icons8_Shutdown_52px_4;
            pictureBox2.Location = new Point(313, 430);
            pictureBox2.Margin = new Padding(4, 3, 4, 3);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(86, 71);
            pictureBox2.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox2.TabIndex = 14;
            pictureBox2.TabStop = false;
            pictureBox2.Click += pictureBox2_Click;
            // 
            // pictureBox3
            // 
            pictureBox3.BackColor = Color.Transparent;
            pictureBox3.Image = Properties.Resources.big_win;
            pictureBox3.Location = new Point(48, 62);
            pictureBox3.Margin = new Padding(4, 3, 4, 3);
            pictureBox3.Name = "pictureBox3";
            pictureBox3.Size = new Size(310, 286);
            pictureBox3.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox3.TabIndex = 15;
            pictureBox3.TabStop = false;
            pictureBox3.Visible = false;
            pictureBox3.Click += pictureBox3_Click;
            // 
            // Game
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(400, 500);
            Controls.Add(pictureBox3);
            Controls.Add(pictureBox2);
            Controls.Add(label3);
            Controls.Add(label4);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(r5);
            Controls.Add(r9);
            Controls.Add(r8);
            Controls.Add(r7);
            Controls.Add(r6);
            Controls.Add(r4);
            Controls.Add(r3);
            Controls.Add(r2);
            Controls.Add(r1);
            Controls.Add(pictureBox1);
            FormBorderStyle = FormBorderStyle.None;
            Margin = new Padding(4, 3, 4, 3);
            Name = "Game";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "68";
            Load += Game_Load;
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)r1).EndInit();
            ((System.ComponentModel.ISupportInitialize)r2).EndInit();
            ((System.ComponentModel.ISupportInitialize)r3).EndInit();
            ((System.ComponentModel.ISupportInitialize)r4).EndInit();
            ((System.ComponentModel.ISupportInitialize)r6).EndInit();
            ((System.ComponentModel.ISupportInitialize)r7).EndInit();
            ((System.ComponentModel.ISupportInitialize)r8).EndInit();
            ((System.ComponentModel.ISupportInitialize)r9).EndInit();
            ((System.ComponentModel.ISupportInitialize)r5).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }


        #endregion

        private PictureBox pictureBox1;
        private PictureBox r1;
        private PictureBox r2;
        private PictureBox r3;
        private PictureBox r4;
        private PictureBox r6;
        private PictureBox r7;
        private PictureBox r8;
        private PictureBox r9;
        private PictureBox r5;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private PictureBox pictureBox2;
        private PictureBox pictureBox3;
    }
}
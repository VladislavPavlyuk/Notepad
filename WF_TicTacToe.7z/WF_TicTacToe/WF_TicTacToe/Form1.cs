using System.Windows.Forms;

namespace WF_TicTacToe
{
    public partial class Form1 : Form
    {
        static string level;
        static string play;

        public Form1()
        {
            InitializeComponent();
            button1.Visible = false;
            pictureBox2.Visible = true;
        }

        private void button1_MouseEnter(object sender, EventArgs e)
        {
            this.button1.ForeColor = Color.Gray;
        }

        private void button1_MouseLeave(object sender, EventArgs e)
        {
            this.button1.ForeColor = Color.GhostWhite;
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void pictureBox2_MouseEnter(object sender, EventArgs e)
        {
            Bitmap img = new Bitmap(WF_TicTacToe.Properties.Resources.icons8_Shutdown_52px_4);

            Bitmap imgHover = new Bitmap(WF_TicTacToe.Properties.Resources.icons8_Shutdown_52px_2);

            this.pictureBox2.Image = imgHover;
        }

        private void pictureBox2_MouseLeave(object sender, EventArgs e)
        {
            Bitmap img = new Bitmap(WF_TicTacToe.Properties.Resources.icons8_Shutdown_52px_4);

            Bitmap imgHover = new Bitmap(WF_TicTacToe.Properties.Resources.icons8_Shutdown_52px_2);

            this.pictureBox2.Image = img;

        }

        private void groupBox2_Enter(object sender, EventArgs e)
        {

        }

        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {
            level = "easy";
        }

        private void radioButton4_CheckedChanged(object sender, EventArgs e)
        {
            level = "medium";
        }

        private void radioButton5_CheckedChanged(object sender, EventArgs e)
        {
            level = "hard";
        }

        private void buttonPlay_Click(object sender, EventArgs e)
        {
            if (play == "Single")
            {
                SinglePlay frm = new(level);
                frm.Show();
                Hide();
            }

            if (play == "Multi")
            {
                Game frm = new Game();
                frm.Show();
                Hide();
            }

            pictureBox2.Visible = true;
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            play = "Single";

            button1.Visible = true;
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            play = "Multi";

            button1.Visible = true;
        }
    }
}
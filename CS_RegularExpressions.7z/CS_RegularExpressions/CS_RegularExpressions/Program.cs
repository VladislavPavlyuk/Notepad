﻿/*
1. Написать приложение, проверяющее с помощью регулярного выражения корректность ввода фамилии и инициалов пользователя в следующем виде: Иванов И.И. либо Иванов ИИ
2. Написать приложение, проверяющее с помощью регулярного выражения корректность ввода адреса электронной почты. Адрес электронной почты должен иметь следующий вид: login@host, где login - последовательность из букв, цифр и символа "_", начинающаяся с буквы. Длина - от 3 до 16 символов. host - строка вида mail.ru или mail.odessa.ua и т.п. В конце host должен содержать от 2 до 3 символов (ua, com, net, ru и т.д.)
3. Написать приложение, проверяющее с помощью регулярного выражения корректность ввода даты в формате Число-Месяц-Год (например, 01-04-2015)
*/

using System;
using System.ComponentModel.DataAnnotations;
using System.Text.RegularExpressions;

namespace Program
{

    class Task1
    {
        public void task()
        {
            try
            {
                Console.Write("\nВведите ФИО в формате Иванов И.И., либо Иванов ИИ : ");

                string input = Console.ReadLine();

                string pattern = @"[А-Я][а-я]+?\s+?[А-Я].??[А-Я].??";

                //string pattern = @"[A-Z][a-z]+?\s+?[A-Z].??[A-Z].??";

                //string pattern = @"\p{IsCyrillicSupplement}[А-Я][а-я]+?\s+?[А-Я].??[А-Я].??";

                //string pattern = @"\p{IsCyrillic}[А - Я][а - я] +\s +[А - Я].??[А - Я].??";

                Regex regex = new Regex(pattern);

                if (regex.IsMatch(input))

                    Console.WriteLine("ФИО введены правильно!");
                else
                    Console.WriteLine("ФИО введены не правильно!");
            }

            catch (Exception)
            {
                throw;
            }
        }
    }

    class Task2
    {
        public void task()
        {
            try
            {
                Console.Write("\nВведите адрес электронной почты, который должен иметь следующий вид: login@host, где login - последовательность из букв, цифр и символа \"_\", начинающаяся с буквы. Длина - от 3 до 16 символов. host - строка вида mail.ru или mail.odessa.ua и т.п. В конце host должен содержать от 2 до 3 символов (ua, com, net, ru и т.д.) : ");

                string input = Console.ReadLine();

                string pattern = @"^[^@_\s]+@[^@\s]+\.[^@\s][a-zA-Z]{2,3}
$";

                Regex regex = new Regex(pattern);

                if (regex.IsMatch(input))
                    Console.WriteLine("email введены правильно!");
                else
                    Console.WriteLine("email введены не правильно!");
            }
            catch (Exception)
            {
                throw;
            }
        }

    }
    class Task3
    {
        public void task()
        {
            try
            {
                Console.Write("\nВводите дату в формате Число-Месяц-Год (например, 01-04-2015) : ");

                string input = Console.ReadLine();

                string pattern = @"(^(0[1-9]|1\d|2\d|3[01])-(0[1-9]|1[0-2])-\d{4}$)";

                Regex regex = new Regex(pattern);

                if (regex.IsMatch(input))

                    Console.WriteLine("Дата введена правильно!");
                else
                    Console.WriteLine("Дата введена не правильно!");
            }
            catch (Exception)
            {
                throw;
            }
        }
    }

    class MainClass
    {
        static void Main()
        {
            ConsoleKeyInfo answer;

            do
            {
                Console.Clear();

                Console.WriteLine("\nЗАДАНИЯ :" +
                    "\r\n\n1. Написать приложение, проверяющее с помощью регулярного выражения корректность ввода фамилии и инициалов пользователя в следующем виде: Иванов И.И. либо Иванов ИИ.\r\n\n2.Написать приложение, проверяющее с помощью регулярного выражения корректность ввода адреса электронной почты.Адрес электронной почты должен иметь следующий вид: login@host, где login - последовательность из букв, цифр и символа _, начинающаяся с буквы.Длина - от 3 до 16 символов.host - строка вида mail.ru или mail.odessa.ua и т.п.В конце host должен содержать от 2 до 3 символов(ua, com, net, ru и т.д.)\r\n\n3.Написать приложение, проверяющее с помощью регулярного выражения корректность ввода даты в формате Число - Месяц - Год(например, 01 - 04 - 2015)\r\n\n0. Выход");

                Console.Write("\nВведите номер задания: ");

                answer = Console.ReadKey();

                switch (answer.Key)
                {
                    case ConsoleKey.D1 :

                        Task1 obj1 = new Task1();

                        obj1.task();

                        break;

                    case ConsoleKey.D2 :

                        Task2 obj2 = new Task2();

                        obj2.task();

                        break;

                    case ConsoleKey.D3 :

                        Task3 obj3 = new Task3();

                        obj3.task();

                        break;

                    case ConsoleKey.D0 :

                        Console.WriteLine("\nДо встречи!");

                        return;

                    default:

                        Console.WriteLine("\nТакого задания нет!");

                        break;
                }
                Console.WriteLine("\nЕщё раз? y/n");

                answer = Console.ReadKey();

            } while (answer.Key == ConsoleKey.Y);


        }
    }


}
﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WPF_Calculator
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Seven_Click(object sender, RoutedEventArgs e)
        {
            Button button = (Button)sender;
            CurrentNumber.Text += button.Content.ToString();
        }

        private void Eight_Click(object sender, RoutedEventArgs e)
        {
            Button button = (Button)sender;
            CurrentNumber.Text += button.Content.ToString();
        }

        private void Nine_Click(object sender, RoutedEventArgs e)
        {
            Button button = (Button)sender;
            CurrentNumber.Text += button.Content.ToString();
        }

        private void Four_Click(object sender, RoutedEventArgs e)
        {
            Button button = (Button)sender;
            CurrentNumber.Text += button.Content.ToString();
        }

        private void Five_Click(object sender, RoutedEventArgs e)
        {
            Button button = (Button)sender;
            CurrentNumber.Text += button.Content.ToString();
        }

        private void Six_Click(object sender, RoutedEventArgs e)
        {
            Button button = (Button)sender;
            CurrentNumber.Text += button.Content.ToString();
        }

        private void One_Click(object sender, RoutedEventArgs e)
        {
            Button button = (Button)sender;
            CurrentNumber.Text += button.Content.ToString();
        }

        private void Two_Click(object sender, RoutedEventArgs e)
        {
            Button button = (Button)sender;
            CurrentNumber.Text += button.Content.ToString();
        }

        private void Three_Click(object sender, RoutedEventArgs e)
        {
            Button button = (Button)sender;
            CurrentNumber.Text += button.Content.ToString();
        }

        private void Point_Click(object sender, RoutedEventArgs e)
        {
            Button button = (Button)sender;
            if (CurrentNumber.Text != "")           
                CurrentNumber.Text += button.Content.ToString();
            else
                CurrentNumber.Text += "0" + button.Content.ToString();
        }

        private void Zero_Click(object sender, RoutedEventArgs e)
        {
            if (CurrentNumber.Text != "")
            {
                Button button = (Button)sender;
                CurrentNumber.Text += button.Content.ToString();
            }
        }

        private void Eq_Click(object sender, RoutedEventArgs e)
        {
            Button button = (Button)sender;
            Expression.Text += CurrentNumber.Text;
            CurrentNumber.Text = " " + button.Content.ToString();
            Expression.Text += CurrentNumber.Text + " ";
            CurrentNumber.Text = "";
        }

        private void Devide_Click(object sender, RoutedEventArgs e)
        {
            Button button = (Button)sender;
            Expression.Text += CurrentNumber.Text;
            CurrentNumber.Text = " " + button.Content.ToString();
            Expression.Text += CurrentNumber.Text + " ";
            CurrentNumber.Text = "";

        }

        private void Multiply_Click(object sender, RoutedEventArgs e)
        {
            Button button = (Button)sender;
            Expression.Text += CurrentNumber.Text;
            CurrentNumber.Text = " " + button.Content.ToString();
            Expression.Text += CurrentNumber.Text + " ";
            CurrentNumber.Text = "";
        }

        private void Minus_Click(object sender, RoutedEventArgs e)
        {
            Button button = (Button)sender;
            Expression.Text += CurrentNumber.Text;
            CurrentNumber.Text = " " + button.Content.ToString();
            Expression.Text += CurrentNumber.Text + " ";
            CurrentNumber.Text = "";
        }

        private void Plus_Click(object sender, RoutedEventArgs e)
        {
            Button button = (Button)sender;
            Expression.Text += CurrentNumber.Text;
            CurrentNumber.Text = " " + button.Content.ToString();
            Expression.Text += CurrentNumber.Text + " ";
            CurrentNumber.Text = "";
        }

        private void Less_Click(object sender, RoutedEventArgs e)
        {
            Button button = (Button)sender;
            CurrentNumber.Text = CurrentNumber.Text.Remove(CurrentNumber.Text.Length - 1);

            if (CurrentNumber.Text == "0.")
                CurrentNumber.Text = CurrentNumber.Text.Remove(CurrentNumber.Text.Length - 2);
        }

        private void CE_Click(object sender, RoutedEventArgs e)
        {
            CurrentNumber.Text = null;
        }

        private void C_Click(object sender, RoutedEventArgs e)
        {
            Expression.Text = null;
            CurrentNumber.Text = null;
        }

        private void correctIfZeroFirst(string s)
        {
            if (s.FirstOrDefault() == '0')
                CurrentNumber.Text = "";// CurrentNumber.Text.Remove(0);
        }
    }
}
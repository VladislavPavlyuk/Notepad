﻿/*
    Игра «Автомобильные гонки»
Разработать игру "Автомобильные гонки" с использованием делегатов.
1. В игре использовать несколько типов автомобилей: спортивные, легковые, грузовые и автобусы.
2. Принцип игры: автомобили двигаются от старта к финишу со скоростями, которые изменяются в установленных пределах случайным образом. Победителем считается автомобиль, пришедший к финишу первым.
Рекомендации по реализации игры
1. Разработать абстрактный класс «автомобиль» (класс Car). Собрать в нем все общие поля, свойства (например, скорость) и методы (например, ехать).
2. Разработать классы автомобилей с конкретной реализацией конструкторов, свойств и методов. В классы автомобилей добавить необходимые события (например, финиш).
3. Класс игры должен производить запуск соревнований автомобилей, выводить сообщения о текущем положении автомобилей, выводить сообщение об автомобиле, победившем в гонках.
4. Создать делегаты, обеспечивающие вызов методов из классов автомобилей (например, выйти на старт, начать гонку).
5. Игра заканчивается, когда какой-то из автомобилей проехал определенное расстояние (старт в положении 0, финиш в положении 100). Уведомление об окончании гонки (прибытии какого-либо автомобиля на финиш) реализовать с помощью событий.
*/

using CS_CarRace;
using System;
using System.Timers;


namespace Delegate
{

    public delegate int CarTracking();
    public delegate void Winner(string w);

    class Program
    {
        static bool finish = false;
        static int count = 0;
        static int yMax = 50, xMax = 200;

        public static Truck racer1 = new(xMax);
        public static SchoolBus racer2 = new(xMax);
        public static Sedan racer3 = new(xMax);
        public static Roadster racer4 = new(xMax);

        static void Main(string[] args)
        {        
            Console.SetWindowSize(xMax, yMax);
           
            racer1.Print(1, 2);
            racer2.Print(1, 12);
            racer3.Print(1, 22);
            racer4.Print(1, 32);

            Console.WriteLine("\t\t\t\tНАЖМИТЕ ЛЮБУЮ КЛАВИШУ ДЛЯ СТАРТА");

            System.Timers.Timer t = new System.Timers.Timer();
            t.Interval = 100;
            t.Elapsed += new ElapsedEventHandler(OnTimer);
            Console.Read();
            t.Start(); 

            racer1.Start += GetSpeed;
            racer2.Start += GetSpeed;
            racer3.Start += GetSpeed;
            racer4.Start += GetSpeed;

            racer1.Finish += Stop;
            racer2.Finish += Stop;
            racer3.Finish += Stop;
            racer4.Finish += Stop;


            Console.WriteLine("\n\t\t\t\t\tНАЖМИТЕ ЛЮБУЮ КЛАВИШУ ДЛЯ ВЫХОДА...");
            Console.ReadKey();
            
        }

        private static int GetSpeed()
        {
            Random rnd = new Random();
            int _speed = rnd.Next(0, 2);
            return _speed;
        }

        private static void Stop(string winner)
        {
            finish = true;
            Console.SetCursorPosition(1, 1);
            Console.WriteLine("\t\t\t\tПОБЕДИТЕЛЬ : {0}, РЕЗУЛЬТАТ: {1} миллисекунд ", winner, count);
        }

        private static void OnTimer(object sender, ElapsedEventArgs arg)
        {
            System.Timers.Timer t = (System.Timers.Timer)sender;
            count++;
            if (finish)
                t.Stop();

            Console.Title = String.Format("C A R  R A C E  {0}", count);
            Console.Clear();
            racer1.Drive();
            racer2.Drive();
            racer3.Drive();
            racer4.Drive();
        }
    }
}



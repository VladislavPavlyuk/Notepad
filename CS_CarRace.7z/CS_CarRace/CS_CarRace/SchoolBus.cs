﻿
using Delegate;

namespace CS_CarRace
{
    public class SchoolBus : Car
    {
        public int _speed, _x = 1, _y = 12, _xMax;

        public SchoolBus(int xMax)
        {
            _xMax = xMax;
        }

        public int Speed
        {
            set => _speed = value;

            get => _speed;
        }

        public int X
        {
            set => _x = value;

            get => _x;
        }

        public int Y
        {
            set => _y = value;

            get => _y;
        }

        public override void Drive()
        {
            if (X < _xMax - 30)
            {
                Speed = (int)(Start?.Invoke());
                X += Speed;
            }
            else
            {
                Finish?.Invoke("SchoolBus");
            }
            Print(X, Y);
        }

        public override void Print(int _x, int _y)
        {
            Console.SetCursorPosition(_x, _y++);
            Console.Write("_________________________");
            Console.SetCursorPosition(_x, _y++);
            Console.Write("|   |     |     |    | |  \\");  
            Console.SetCursorPosition(_x, _y++);
            Console.Write("|___|_____|_____|____|_|___\\"); 
            Console.SetCursorPosition(_x, _y++);
            Console.Write("|      shoolbus      | |    \\");
            Console.SetCursorPosition(_x, _y++);
            Console.Write("`--(o)(o)--------------(o)--'");
        }

        public event CarTracking Start;
        public event Winner Finish;
    }
}
